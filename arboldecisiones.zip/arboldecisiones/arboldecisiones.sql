/*
SQLyog Community
MySQL - 10.0.34-MariaDB-0ubuntu0.16.04.1 : Database - catalogos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `arboldecisiones`;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_decisiones.csv' IGNORE INTO TABLE arboldecisiones.decisiones FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_detalles_solucion_decisiones.csv' IGNORE INTO TABLE arboldecisiones.detalles_solucion_decisiones FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_marcaRapida.csv' IGNORE INTO TABLE arboldecisiones.marcaRapida FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso00.csv' IGNORE INTO TABLE arboldecisiones.paso00 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso01.csv' IGNORE INTO TABLE arboldecisiones.paso01 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso02.csv' IGNORE INTO TABLE arboldecisiones.paso02 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso03.csv' IGNORE INTO TABLE arboldecisiones.paso03 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso04.csv' IGNORE INTO TABLE arboldecisiones.paso04 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso05.csv' IGNORE INTO TABLE arboldecisiones.paso05 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso06.csv' IGNORE INTO TABLE arboldecisiones.paso06 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso07.csv' IGNORE INTO TABLE arboldecisiones.paso07 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso08.csv' IGNORE INTO TABLE arboldecisiones.paso08 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso09.csv' IGNORE INTO TABLE arboldecisiones.paso09 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso10.csv' IGNORE INTO TABLE arboldecisiones.paso10 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso11.csv' IGNORE INTO TABLE arboldecisiones.paso11 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso12.csv' IGNORE INTO TABLE arboldecisiones.paso12 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso13.csv' IGNORE INTO TABLE arboldecisiones.paso13 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso14.csv' IGNORE INTO TABLE arboldecisiones.paso14 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso15.csv' IGNORE INTO TABLE arboldecisiones.paso15 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso16.csv' IGNORE INTO TABLE arboldecisiones.paso16 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_paso17.csv' IGNORE INTO TABLE arboldecisiones.paso17 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_pasoArbol.csv' IGNORE INTO TABLE arboldecisiones.pasoArbol FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_reportearbol.csv' IGNORE INTO TABLE arboldecisiones.reportearbol FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/arboldecisiones/arboldecisiones_tbresumen.csv' IGNORE INTO TABLE arboldecisiones.tbresumen FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;
