/*
SQLyog Community
MySQL - 10.0.34-MariaDB-0ubuntu0.16.04.1 : Database - catalogos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `catalogos`;

LOAD DATA CONCURRENT INFILE '/catalogos/catalogos_analgesicos.csv' IGNORE INTO TABLE catalogos.analgesicos FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/catalogos/catalogos_db_fuentes.csv' IGNORE INTO TABLE catalogos.db_fuentes FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/catalogos/catalogos_oui_fuentes.csv' IGNORE INTO TABLE catalogos.oui_fuentes FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/catalogos/catalogos_querys.csv' IGNORE INTO TABLE catalogos.querys FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

