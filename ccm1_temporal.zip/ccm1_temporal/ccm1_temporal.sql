/*
SQLyog Community
MySQL - 10.0.34-MariaDB-0ubuntu0.16.04.1 : Database - catalogos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `ccm1_temporal`;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_access_temp.csv' IGNORE INTO TABLE ccm1_temporal.access_temp FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_access_tempx.csv' IGNORE INTO TABLE ccm1_temporal.access_tempx FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_casa_down_util_c.csv' IGNORE INTO TABLE ccm1_temporal.casa_down_util_c FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_casa_down_util_sw.csv' IGNORE INTO TABLE ccm1_temporal.casa_down_util_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_casa_upstream_util_c.csv' IGNORE INTO TABLE ccm1_temporal.casa_upstream_util_c FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_cmts_casa_sum.csv' IGNORE INTO TABLE ccm1_temporal.cmts_casa_sum FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_phy_temp.csv' IGNORE INTO TABLE ccm1_temporal.phy_temp FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_phy_tempx_1.csv' IGNORE INTO TABLE ccm1_temporal.phy_tempx_1 FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_scm_sum.csv' IGNORE INTO TABLE ccm1_temporal.scm_sum FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_scm_temp.csv' IGNORE INTO TABLE ccm1_temporal.scm_temp FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_scm_tempx.csv' IGNORE INTO TABLE ccm1_temporal.scm_tempx FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_sum_temp.csv' IGNORE INTO TABLE ccm1_temporal.sum_temp FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/ccm1_temporal/ccm1_temporal_sum_tempx.csv' IGNORE INTO TABLE ccm1_temporal.sum_tempx FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;




