/*
SQLyog Community
MySQL - 10.0.34-MariaDB-0ubuntu0.16.04.1 : Database - catalogos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `reportes`;

LOAD DATA CONCURRENT INFILE '/reportes/reportes_portadorasxpuerto_puertos_casa.csv' IGNORE INTO TABLE reportes.portadorasxpuerto_puertos_casa FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/reportes/reportes_show_docsis_downstream_sw.csv' IGNORE INTO TABLE reportes.show_docsis_downstream_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;
