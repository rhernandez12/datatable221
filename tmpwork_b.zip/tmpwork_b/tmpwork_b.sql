/*
SQLyog Community
MySQL - 10.0.34-MariaDB-0ubuntu0.16.04.1 : Database - catalogos
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
USE `tmpwork_b`;

LOAD DATA CONCURRENT INFILE '/tmpwork_b/tmpwork_b_cisco_phy_sw.csv' IGNORE INTO TABLE tmpwork_b.cisco_phy_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/tmpwork_b/tmpwork_b_cisco_scm_sw.csv' IGNORE INTO TABLE tmpwork_b.cisco_scm_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/tmpwork_b/tmpwork_b_cisco_sw.csv' IGNORE INTO TABLE tmpwork_b.cisco_sw FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/tmpwork_b/tmpwork_b_cisco_sw_historial.csv' IGNORE INTO TABLE tmpwork_b.cisco_sw_historial FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/tmpwork_b/tmpwork_b_cmts_ip_cols_phy.csv' IGNORE INTO TABLE tmpwork_b.cmts_ip_cols_phy FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;

LOAD DATA CONCURRENT INFILE '/tmpwork_b/tmpwork_b_cmts_ip_cols_scm.csv' IGNORE INTO TABLE tmpwork_b.cmts_ip_cols_scm FIELDS TERMINATED by ',' LINES TERMINATED by '\r\n' IGNORE 1 LINES;
